"""
pydig is a library of routines used by pydig - a python script to 
perform a variety of DNS queries, loosely modelled on the BIND dig 
program.

"""
